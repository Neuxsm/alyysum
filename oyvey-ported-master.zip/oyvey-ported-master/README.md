<div align="center">

# oyvey-ported
Kosher client base ported to Minecraft 1.21.1 by [@cattyngmd](https://github.com/cattyngmd)

<img src="https://i.imgur.com/Lu6rDJB.png" width="90%" />

# Why
![](https://i.imgur.com/VYjIphG.png)

# What
Add stuff to it like you would add stuff to your 1.12.2 OyVey paste

</div>
